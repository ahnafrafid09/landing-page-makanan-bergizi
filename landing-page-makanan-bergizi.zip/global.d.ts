declare module "react-modal";
