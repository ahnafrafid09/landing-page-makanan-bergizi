(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_contact_page_tsx_a914a87d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_contact_page_tsx_a914a87d._.js",
  "chunks": [
    "static/chunks/node_modules_ac5cf9a9._.js",
    "static/chunks/components_5f164b38._.js"
  ],
  "source": "dynamic"
});
