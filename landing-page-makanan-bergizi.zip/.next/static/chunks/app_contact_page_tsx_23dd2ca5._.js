(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_contact_page_tsx_23dd2ca5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_contact_page_tsx_23dd2ca5._.js",
  "chunks": [
    "static/chunks/node_modules_a8a9fff3._.js",
    "static/chunks/components_51ac3d9c._.js"
  ],
  "source": "dynamic"
});
