(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_about_page_tsx_23bdc3dc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_about_page_tsx_23bdc3dc._.js",
  "chunks": [
    "static/chunks/node_modules_98f733c7._.js",
    "static/chunks/components_pages_about_Journey_tsx_d4a29fa7._.js",
    "static/chunks/node_modules_swiper_b167c7bf._.css"
  ],
  "source": "dynamic"
});
