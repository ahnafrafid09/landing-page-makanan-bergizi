(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_aaf7d535._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_aaf7d535._.js",
  "chunks": [
    "static/chunks/[root of the server]__957b9e48._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_b417b619._.js",
    "static/chunks/node_modules_005e322f._.js",
    "static/chunks/components_2f466a75._.js"
  ],
  "source": "dynamic"
});
