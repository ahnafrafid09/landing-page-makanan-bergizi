(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_layout_tsx_60e850c1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_layout_tsx_60e850c1._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6a48e5a0._.js",
    "static/chunks/_0d8ca746._.js"
  ],
  "source": "dynamic"
});
