(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_about_page_tsx_c014685a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_about_page_tsx_c014685a._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8e4be873._.js",
    "static/chunks/node_modules_62be88a9._.js",
    "static/chunks/components_pages_about_1443b24e._.js",
    "static/chunks/node_modules_swiper_b167c7bf._.css"
  ],
  "source": "dynamic"
});
