(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_layout_tsx_60e850c1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_layout_tsx_60e850c1._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_05a2d3f0._.js",
    "static/chunks/node_modules_f7f39f7d._.js",
    "static/chunks/components_2f466a75._.js"
  ],
  "source": "dynamic"
});
