(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_registration_page_tsx_dac6f5ee._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_registration_page_tsx_dac6f5ee._.js",
  "chunks": [
    "static/chunks/components_pages_registration_FormRegistration_tsx_170d3a3c._.js"
  ],
  "source": "dynamic"
});
