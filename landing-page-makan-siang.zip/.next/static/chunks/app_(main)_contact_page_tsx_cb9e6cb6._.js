(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_contact_page_tsx_cb9e6cb6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_contact_page_tsx_cb9e6cb6._.js",
  "chunks": [
    "static/chunks/_3aeaa6d0._.js"
  ],
  "source": "dynamic"
});
