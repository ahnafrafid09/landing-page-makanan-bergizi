(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_about_page_tsx_b7f064f5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_about_page_tsx_b7f064f5._.js",
  "chunks": [
    "static/chunks/node_modules_e4d8f42d._.js",
    "static/chunks/components_pages_about_1443b24e._.js",
    "static/chunks/node_modules_swiper_b167c7bf._.css"
  ],
  "source": "dynamic"
});
