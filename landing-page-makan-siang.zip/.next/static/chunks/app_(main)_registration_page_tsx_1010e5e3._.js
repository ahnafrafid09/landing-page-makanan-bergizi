(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_registration_page_tsx_1010e5e3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_registration_page_tsx_1010e5e3._.js",
  "chunks": [
    "static/chunks/components_pages_registration_FormRegistration_tsx_170d3a3c._.js"
  ],
  "source": "dynamic"
});
