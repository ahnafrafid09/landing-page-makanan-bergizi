(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_layout_tsx_3fd49c8f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_layout_tsx_3fd49c8f._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_c5f08d57._.js",
    "static/chunks/node_modules_f7f39f7d._.js",
    "static/chunks/components_2f466a75._.js"
  ],
  "source": "dynamic"
});
