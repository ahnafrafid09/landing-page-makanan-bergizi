(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(auth)_login_page_tsx_c51eead6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(auth)_login_page_tsx_c51eead6._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/components_auth_LoginForm_tsx_9ab58bf1._.js"
  ],
  "source": "dynamic"
});
