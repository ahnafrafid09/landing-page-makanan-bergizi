(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_layout_tsx_c014685a._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_layout_tsx_c014685a._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f15c45c4._.js",
    "static/chunks/node_modules_005e322f._.js",
    "static/chunks/components_2f466a75._.js"
  ],
  "source": "dynamic"
});
