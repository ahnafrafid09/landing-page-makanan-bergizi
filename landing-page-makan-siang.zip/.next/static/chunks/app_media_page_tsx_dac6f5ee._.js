(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_media_page_tsx_dac6f5ee._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_media_page_tsx_dac6f5ee._.js",
  "chunks": [
    "static/chunks/node_modules_328cfa06._.js",
    "static/chunks/components_d9991f8c._.js"
  ],
  "source": "dynamic"
});
