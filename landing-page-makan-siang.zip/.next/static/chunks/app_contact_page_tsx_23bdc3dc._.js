(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_contact_page_tsx_23bdc3dc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_contact_page_tsx_23bdc3dc._.js",
  "chunks": [
    "static/chunks/_3aeaa6d0._.js"
  ],
  "source": "dynamic"
});
