(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(main)_registration_page_tsx_b7f064f5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(main)_registration_page_tsx_b7f064f5._.js",
  "chunks": [
    "static/chunks/components_pages_registration_FormRegistration_tsx_170d3a3c._.js"
  ],
  "source": "dynamic"
});
